#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import serial
import time
import xml.etree.ElementTree as ET

def test_xml_communication():
    """Test bezpośredniej komunikacji XML z drukarką Novitus Deon"""
    
    port = '/dev/cu.usbmodem101'
    baudrate = 9600
    
    print(f"🖨️ TEST KOMUNIKACJI XML Z DRUKARKĄ NOVITUS DEON")
    print(f"🔌 Port: {port}")
    print(f"⚡ Baudrate: {baudrate}")
    print("=" * 60)
    
    try:
        # Otwórz port
        ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=5,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False
        )
        
        print(f"✅ Port {port} otwarty pomyślnie")
        
        # Poczekaj na stabilizację
        time.sleep(1)
        
        # Wyczyść bufory
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        
        # Test 1: Wysyłanie prostego XML-a statusu
        print("\\n🔍 Test 1: Wysyłam zapytanie XML o status...")
        
        status_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<FiscalPrinter>
    <Request>
        <Command>GetStatus</Command>
        <Parameters/>
    </Request>
</FiscalPrinter>'''
        
        xml_bytes = status_xml.encode('utf-8')
        xml_with_etx = xml_bytes + b'\\x03'  # ETX na końcu
        
        print(f"📤 Wysyłam XML ({len(xml_bytes)} bajtów):")
        print(status_xml)
        
        ser.write(xml_with_etx)
        ser.flush()
        
        # Czekaj na odpowiedź
        time.sleep(3)
        response = ser.read_all()
        
        if response:
            print(f"\\n📥 Otrzymano odpowiedź ({len(response)} bajtów):")
            print(f"HEX: {response.hex()}")
            
            try:
                response_str = response.decode('utf-8', errors='ignore')
                print(f"ASCII: {response_str}")
                
                # Sprawdź czy to XML
                if '<' in response_str and '>' in response_str:
                    print("✅ Odpowiedź wygląda na XML!")
                    try:
                        root = ET.fromstring(response_str)
                        print(f"✅ Poprawny XML - root: {root.tag}")
                    except:
                        print("⚠️ Niepoprawna struktura XML")
                else:
                    print("❓ Odpowiedź nie wygląda na XML")
                    
            except Exception as e:
                print(f"❌ Błąd dekodowania: {e}")
        else:
            print("❌ Brak odpowiedzi na XML status")
        
        # Test 2: Alternatywny format XML
        print("\\n🔍 Test 2: Próbuję alternatywny format XML...")
        
        alt_xml = '''<?xml version="1.0"?>
<novitus>
    <command>status</command>
</novitus>'''
        
        alt_bytes = alt_xml.encode('utf-8') + b'\\r\\n'
        
        ser.write(alt_bytes)
        ser.flush()
        
        time.sleep(2)
        response2 = ser.read_all()
        
        if response2:
            print(f"📥 Alternatywna odpowiedź: {response2.hex()}")
            try:
                response2_str = response2.decode('utf-8', errors='ignore')
                print(f"ASCII: {response2_str}")
            except:
                pass
        else:
            print("❌ Brak odpowiedzi na alternatywny XML")
        
        # Test 3: Surowe dane bez XML
        print("\\n🔍 Test 3: Próbuję podstawowe komendy...")
        
        # Różne możliwe komendy
        commands = [
            (b'STATUS\\r\\n', 'STATUS'),
            (b'?\\r\\n', 'Zapytanie'),
            (b'\\x10', 'DLE'),
            (b'\\x05', 'ENQ'),
            (b'VER\\r\\n', 'Wersja'),
            (b'INFO\\r\\n', 'Info')
        ]
        
        for cmd_bytes, cmd_name in commands:
            print(f"  📤 {cmd_name}: {cmd_bytes}")
            ser.write(cmd_bytes)
            ser.flush()
            time.sleep(1)
            
            cmd_response = ser.read_all()
            if cmd_response:
                print(f"  📥 {cmd_name} -> {cmd_response.hex()} | {cmd_response.decode('ascii', errors='ignore')}")
            else:
                print(f"  📭 {cmd_name} -> Brak odpowiedzi")
        
        ser.close()
        print(f"\\n🔒 Port {port} zamknięty")
        
    except serial.SerialException as e:
        print(f"❌ Błąd portu szeregowego: {e}")
    except Exception as e:
        print(f"❌ Nieoczekiwany błąd: {e}")
    
    print("\\n" + "=" * 60)
    print("💡 WNIOSKI:")
    print("1. Jeśli drukarka odpowiedziała na XML - protokół XML działa")
    print("2. Jeśli odpowiedziała na podstawowe komendy - może używać innego protokołu")
    print("3. Brak odpowiedzi może oznaczać:")
    print("   - Drukarka w trybie offline/serwisowym")
    print("   - Niepoprawne parametry komunikacji")
    print("   - Drukarka oczekuje innego formatu")

if __name__ == "__main__":
    test_xml_communication()
