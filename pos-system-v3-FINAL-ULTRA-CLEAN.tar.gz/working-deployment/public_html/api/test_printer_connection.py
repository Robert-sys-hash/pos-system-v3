#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import serial
import time
import sys

def test_printer_connection():
    """Test czy drukarka Novitus Deon odpowiada na komendy"""
    
    port = '/dev/cu.usbmodem101'
    baudrate = 9600
    
    print(f"🔌 Testowanie połączenia z drukarką na {port}")
    print("=" * 50)
    
    try:
        # Otwórz port
        ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=2,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False
        )
        
        print(f"✅ Port {port} otwarty pomyślnie")
        print(f"📊 Konfiguracja: {baudrate} 8N1")
        
        # Sprawdź czy port jest gotowy
        time.sleep(0.5)
        
        # Test 1: ENQ - zapytanie o status
        print("\n🔍 Test 1: Wysyłam ENQ (zapytanie o status)...")
        ser.write(b'\x05')  # ENQ
        ser.flush()
        
        # Czekaj na odpowiedź
        time.sleep(1)
        response = ser.read_all()
        
        if response:
            print(f"✅ Otrzymano odpowiedź: {response.hex()} ({len(response)} bajtów)")
            for byte in response:
                print(f"   Bajt: 0x{byte:02X} ({byte}) {'ACK' if byte == 0x06 else 'NAK' if byte == 0x15 else 'inne'}")
        else:
            print("❌ Brak odpowiedzi na ENQ")
        
        # Test 2: DLE - sprawdzenie stanu drukarki
        print("\n🔍 Test 2: Wysyłam DLE (sprawdzenie stanu)...")
        ser.write(b'\x10')  # DLE
        ser.flush()
        
        time.sleep(1)
        response = ser.read_all()
        
        if response:
            print(f"✅ Otrzymano odpowiedź na DLE: {response.hex()} ({len(response)} bajtów)")
            for byte in response:
                print(f"   Bajt: 0x{byte:02X} ({byte})")
        else:
            print("❌ Brak odpowiedzi na DLE")
        
        # Test 3: Sprawdzenie buffora
        print("\n🔍 Test 3: Sprawdzam czy drukarka wysyła dane...")
        time.sleep(0.5)
        all_data = ser.read_all()
        
        if all_data:
            print(f"📥 Dodatkowe dane: {all_data.hex()}")
        else:
            print("📭 Brak dodatkowych danych")
        
        ser.close()
        print(f"\n🔒 Port {port} zamknięty")
        
        return len(response) > 0 if 'response' in locals() else False
        
    except serial.SerialException as e:
        print(f"❌ Błąd portu szeregowego: {e}")
        return False
    except Exception as e:
        print(f"❌ Nieoczekiwany błąd: {e}")
        return False

if __name__ == "__main__":
    print("🖨️ TEST POŁĄCZENIA Z DRUKARKĄ NOVITUS DEON")
    print("📋 Sprawdzanie komunikacji przez port szeregowy")
    print()
    
    success = test_printer_connection()
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 SUKCES! Drukarka odpowiada na komendy!")
        print("💡 System może przejść do prawdziwego drukowania fiskalnego")
    else:
        print("⚠️ Drukarka nie odpowiada lub występują problemy z komunikacją")
        print("💡 Sprawdź:")
        print("   - Czy drukarka jest włączona i w trybie online")
        print("   - Czy kabel USB jest dobrze podłączony")
        print("   - Czy drukarka jest w trybie fiskalnym (nie serwisowym)")
        print("   - Czy nie ma blokady lub błędów na drukarce")
