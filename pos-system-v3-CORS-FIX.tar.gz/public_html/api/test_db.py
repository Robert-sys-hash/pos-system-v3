#!/usr/bin/env python3

import sqlite3
import sys
import os

# Dodaj ścieżkę do głównego katalogu
sys.path.append('../../')

def test_database():
    """Test połączenia z bazą danych"""
    db_path = '../../kupony.db'
    
    print(f"🔍 Testowanie bazy danych: {db_path}")
    print(f"Plik istnieje: {os.path.exists(db_path)}")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Sprawdź tabele
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
        tables = cursor.fetchall()
        print(f"\n📊 Znalezione tabele ({len(tables)}):")
        for table in tables:
            print(f"  - {table[0]}")
        
        # Sprawdź strukturę pos_zmiany
        if ('pos_zmiany',) in tables:
            print(f"\n🔍 Struktura tabeli pos_zmiany:")
            cursor.execute("PRAGMA table_info(pos_zmiany);")
            columns = cursor.fetchall()
            for col in columns:
                print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
            
            # Sprawdź liczbę rekordów
            cursor.execute("SELECT COUNT(*) FROM pos_zmiany;")
            count = cursor.fetchone()[0]
            print(f"\n📈 Liczba rekordów w pos_zmiany: {count}")
            
            # Pokaż przykładowe rekordy
            if count > 0:
                cursor.execute("SELECT * FROM pos_zmiany ORDER BY id DESC LIMIT 3;")
                records = cursor.fetchall()
                print(f"\n📋 Przykładowe rekordy:")
                for record in records:
                    print(f"  {record}")
        
        # Sprawdź czy istnieje tabela zmiany_kasowe
        if ('zmiany_kasowe',) in tables:
            print(f"\n🔍 Struktura tabeli zmiany_kasowe:")
            cursor.execute("PRAGMA table_info(zmiany_kasowe);")
            columns = cursor.fetchall()
            for col in columns:
                print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
                
            cursor.execute("SELECT COUNT(*) FROM zmiany_kasowe;")
            count = cursor.fetchone()[0]
            print(f"\n📈 Liczba rekordów w zmiany_kasowe: {count}")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Błąd: {e}")

if __name__ == "__main__":
    test_database()
