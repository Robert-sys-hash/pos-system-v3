#!/usr/bin/env python3
"""
Uproszczony backend do testowania kategorii
"""

from flask import Flask, jsonify
from flask_cors import CORS
import os
import sys

# Dodaj ścieżkę do modułów
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)

# Konfiguracja CORS
CORS(app, 
     origins=['http://localhost:3002', 'http://localhost:5002', 'http://127.0.0.1:3002', 'http://127.0.0.1:5002'],
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Rejestracja tylko blueprintu kategorii
try:
    from api.categories import categories_bp
    app.register_blueprint(categories_bp, url_prefix='/api')
    print("✅ Categories blueprint OK")
except Exception as e:
    print(f"❌ Błąd categories blueprint: {e}")
    sys.exit(1)

@app.route('/api/info')
def info():
    return jsonify({
        'success': True,
        'message': 'Backend testowy dla kategorii',
        'endpoints': ['/api/categories']
    })

if __name__ == '__main__':
    print("🚀 Uruchamiam testowy backend...")
    app.run(host='0.0.0.0', port=5003, debug=True)
