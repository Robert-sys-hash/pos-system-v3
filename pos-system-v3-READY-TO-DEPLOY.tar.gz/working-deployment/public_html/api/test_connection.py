#!/usr/bin/env python3
"""
Test połączenia z bazą danych
Sprawdza czy backend może się połączyć z bazą kupony.db
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.database import get_db_connection, execute_query

def test_database_connection():
    print("🔍 Testowanie połączenia z bazą danych...")
    
    # Test 1: Sprawdź połączenie
    conn = get_db_connection()
    if not conn:
        print("❌ Nie można połączyć się z bazą danych")
        return False
    
    print("✅ Połączenie z bazą OK")
    conn.close()
    
    # Test 2: Sprawdź czy tabela kuponów istnieje
    try:
        result = execute_query("SELECT name FROM sqlite_master WHERE type='table' AND name='kupony'")
        if result:
            print("✅ Tabela 'kupony' istnieje")
        else:
            print("❌ Tabela 'kupony' nie istnieje")
            return False
    except Exception as e:
        print(f"❌ Błąd sprawdzania tabeli: {e}")
        return False
    
    # Test 3: Sprawdź strukturę tabeli kuponów
    try:
        result = execute_query("PRAGMA table_info(kupony)")
        if result:
            print("✅ Struktura tabeli 'kupony':")
            for col in result:
                print(f"   - {col['name']}: {col['type']}")
        else:
            print("❌ Nie można pobrać struktury tabeli")
    except Exception as e:
        print(f"❌ Błąd sprawdzania struktury: {e}")
    
    # Test 4: Sprawdź liczbę kuponów
    try:
        result = execute_query("SELECT COUNT(*) as count FROM kupony")
        if result:
            count = result[0]['count']
            print(f"✅ Liczba kuponów w bazie: {count}")
        else:
            print("❌ Nie można pobrać liczby kuponów")
    except Exception as e:
        print(f"❌ Błąd liczenia kuponów: {e}")
    
    print("🎉 Test połączenia zakończony")
    return True

if __name__ == '__main__':
    success = test_database_connection()
    sys.exit(0 if success else 1)
