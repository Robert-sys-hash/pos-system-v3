#!/usr/bin/env python3
"""
Analiza protokołu Novitus na podstawie znanych odpowiedzi
"""

import serial
import time

def analyze_novitus_protocol():
    """Analiza protokołu Novitus"""
    try:
        port = '/dev/cu.usbmodem1101'
        baudrate = 9600
        
        print(f"🔍 Analiza protokołu Novitus na {port}")
        
        connection = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=2.0
        )
        
        print(f"✅ Połączenie nawiązane: {connection.is_open}")
        
        # Znane komendy które działają
        working_commands = [
            (b'\x10', 'DLE - odpowiada t'),
            (b'\x05', 'ENQ - odpowiada e'),
            (b'\x1a', 'SUB - pełna informacja o statusie'),
        ]
        
        print(f"\n📤 Test znanych komend:")
        
        for cmd, desc in working_commands:
            try:
                print(f"\n📤 {desc}")
                print(f"   Komenda: {cmd.hex()}")
                
                connection.flushInput()
                connection.write(cmd)
                time.sleep(0.5)
                
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    
                    # Analiza odpowiedzi SUB
                    if cmd == b'\x1a':
                        print(f"   🔍 Analiza statusu:")
                        try:
                            decoded = response.decode('cp1250', errors='ignore')
                            print(f"   Dekodowane: {repr(decoded)}")
                            
                            # Próba parsowania statusu
                            if ';' in decoded:
                                parts = decoded.split(';')
                                print(f"   Części statusu: {parts}")
                        except:
                            pass
                else:
                    print(f"⚠️ Brak odpowiedzi")
                    
            except Exception as e:
                print(f"❌ Błąd: {e}")
        
        # Test potencjalnych komend fiscal printer
        print(f"\n📤 Test potencjalnych komend fiskalnych:")
        
        fiscal_commands = [
            # Kombincje z DLE (0x10) + różne bajty
            (b'\x10\x20', 'DLE + SP (space)'),
            (b'\x10\x0D', 'DLE + CR'),
            (b'\x10\x0A', 'DLE + LF'),
            
            # Komendy z SUB (0x1A) + różne bajty
            (b'\x1a\x53', 'SUB + S (Start)'),
            (b'\x1a\x45', 'SUB + E (End)'),
            (b'\x1a\x50', 'SUB + P (Print)'),
            (b'\x1a\x52', 'SUB + R (Receipt)'),
            (b'\x1a\x58', 'SUB + X (X Report)'),
            (b'\x1a\x5A', 'SUB + Z (Z Report)'),
            
            # Kombinacje z ENQ (0x05)
            (b'\x05\x53', 'ENQ + S'),
            (b'\x05\x52', 'ENQ + R'),
            
            # Inne kombinacje
            (b'\x02\x53\x03', 'STX + S + ETX'),
            (b'\x02\x50\x03', 'STX + P + ETX'),
            (b'\x02\x52\x03', 'STX + R + ETX'),
        ]
        
        for cmd, desc in fiscal_commands:
            try:
                print(f"\n📤 {desc}")
                print(f"   Komenda: {cmd.hex()}")
                
                connection.flushInput()
                connection.write(cmd)
                time.sleep(0.5)
                
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        pass
                else:
                    print(f"⚠️ Brak odpowiedzi")
                    
            except Exception as e:
                print(f"❌ Błąd: {e}")
        
        connection.close()
        print(f"\n✅ Analiza zakończona")
        
    except Exception as e:
        print(f"❌ Błąd analizy: {e}")

if __name__ == "__main__":
    analyze_novitus_protocol()
