#!/usr/bin/env python3
"""
Test wszystkich bajtów kontrolnych dla drukarki Novitus
"""

import serial
import time

def test_all_control_bytes():
    """Test wszystkich bajtów kontrolnych"""
    try:
        port = '/dev/cu.usbmodem1101'
        baudrate = 9600
        
        print(f"🔍 Nawiązuję połączenie z drukarką Novitus na {port}")
        
        connection = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=2.0
        )
        
        print(f"✅ Połączenie nawiązane: {connection.is_open}")
        
        # Test wszystkich bajtów kontrolnych (0x00-0x1F)
        print(f"\n📤 Test bajtów kontrolnych (0x00-0x1F):")
        
        for byte_val in range(0x00, 0x20):
            try:
                cmd = bytes([byte_val])
                
                print(f"\n📤 Bajt: 0x{byte_val:02X}")
                
                # Wyczyść bufor wejściowy
                connection.flushInput()
                
                # Wyślij komendę
                connection.write(cmd)
                time.sleep(0.3)
                
                # Sprawdź odpowiedź
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        print(f"   Tekst: [nieparsowalne]")
                else:
                    print(f"⚠️ Brak odpowiedzi")
                    
            except Exception as e:
                print(f"❌ Błąd bajtu 0x{byte_val:02X}: {e}")
        
        # Test bajtów ASCII dla komend (litery A-Z)
        print(f"\n📤 Test liter A-Z (potencjalne komendy):")
        
        for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            try:
                cmd = letter.encode('ascii')
                
                print(f"\n📤 Litera: {letter}")
                
                connection.flushInput()
                connection.write(cmd)
                time.sleep(0.3)
                
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        print(f"   Tekst: [nieparsowalne]")
                else:
                    print(f"⚠️ Brak odpowiedzi")
                    
            except Exception as e:
                print(f"❌ Błąd litery {letter}: {e}")
        
        connection.close()
        print(f"\n✅ Test zakończony pomyślnie")
        
    except Exception as e:
        print(f"❌ Błąd testu: {e}")

if __name__ == "__main__":
    test_all_control_bytes()
