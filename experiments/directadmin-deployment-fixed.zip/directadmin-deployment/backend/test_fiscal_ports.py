#!/usr/bin/env python3
"""
Skrypt do testowania połączenia z drukarką fiskalną Novitus
na różnych portach i z różnymi prędkościami
"""

import serial
import time
import logging
from serial.tools import list_ports

# Konfiguracja logowania
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_port(port, baudrate=9600, timeout=2.0):
    """Test pojedynczego portu"""
    try:
        print(f"\n🔍 Testuję port: {port} z prędkością {baudrate}")
        
        # Nawiąż połączenie
        connection = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=timeout
        )
        
        print(f"✅ Połączenie nawiązane: {connection.is_open}")
        
        # Wyślij prosty test komunikacji
        test_commands = [
            '<?xml version="1.0" encoding="windows-1250"?>\n<root><GetStatus/></root>\n',
            'AT\r\n',  # Podstawowy test AT
            '\x1B\x05',  # ESC ENQ - zapytanie o status
        ]
        
        for i, cmd in enumerate(test_commands):
            try:
                print(f"  📤 Wysyłam komendę {i+1}: {repr(cmd[:20])}")
                connection.write(cmd.encode('cp1250' if 'xml' in cmd else 'ascii'))
                time.sleep(1.0)
                
                # Sprawdź odpowiedź
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"  📥 Odpowiedź ({len(response)} bajtów): {response[:50]}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"  📄 Dekodowane: {decoded[:100]}")
                    except:
                        print(f"  📄 Hex: {response.hex()}")
                    
                    # Jeśli dostaliśmy odpowiedź, drukarka prawdopodobnie działa
                    connection.close()
                    return True
                else:
                    print(f"  ⚠️ Brak odpowiedzi na komendę {i+1}")
                    
            except Exception as e:
                print(f"  ❌ Błąd wysyłania komendy {i+1}: {e}")
        
        connection.close()
        print(f"❌ Port {port} nie odpowiada")
        return False
        
    except Exception as e:
        print(f"❌ Błąd połączenia z {port}: {e}")
        return False

def main():
    print("🔍 DIAGNOZA DRUKARKI FISKALNEJ NOVITUS")
    print("=" * 50)
    
    # Lista dostępnych portów
    print("\n📋 Dostępne porty szeregowe:")
    ports = list_ports.comports()
    for port in ports:
        print(f"  • {port.device} - {port.description}")
    
    # Dodaj znalezione porty USB
    import glob
    usb_ports = glob.glob('/dev/cu.usb*') + glob.glob('/dev/tty.usb*')
    
    print(f"\n🔍 Znalezione porty USB: {usb_ports}")
    
    # Testuj wszystkie porty z różnymi prędkościami
    test_ports = []
    for port in ports:
        test_ports.append(port.device)
    test_ports.extend(usb_ports)
    
    baudrates = [9600, 19200, 38400, 57600, 115200]
    
    successful_configs = []
    
    for port in test_ports:
        for baudrate in baudrates:
            if test_port(port, baudrate):
                successful_configs.append((port, baudrate))
                print(f"✅ SUKCES: {port} z prędkością {baudrate}")
    
    print(f"\n📊 PODSUMOWANIE:")
    if successful_configs:
        print("✅ Działające konfiguracje:")
        for port, baudrate in successful_configs:
            print(f"  • Port: {port}, Prędkość: {baudrate}")
    else:
        print("❌ Nie znaleziono działających konfiguracji")
        print("\n🔧 Sprawdź:")
        print("  • Czy drukarka jest włączona")
        print("  • Czy kabel USB jest podłączony")
        print("  • Czy drukarka jest w trybie online")
        print("  • Czy sterowniki USB są zainstalowane")

if __name__ == "__main__":
    main()
