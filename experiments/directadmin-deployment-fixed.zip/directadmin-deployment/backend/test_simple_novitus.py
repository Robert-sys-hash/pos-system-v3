#!/usr/bin/env python3
"""
Prosty test komunikacji z drukarką Novitus - pojedyncze bajty
"""

import serial
import time

def test_simple_novitus():
    """Test prostych komend Novitus"""
    try:
        port = '/dev/cu.usbmodem1101'
        baudrate = 9600
        
        print(f"🔍 Nawiązuję połączenie z drukarką Novitus na {port}")
        
        connection = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=3.0
        )
        
        print(f"✅ Połączenie nawiązane: {connection.is_open}")
        
        # Test pojedynczych bajtów kontrolnych
        test_commands = [
            (b'\x10', 'DLE (Data Link Escape)'),
            (b'\x05', 'ENQ (Enquiry)'), 
            (b'\x06', 'ACK (Acknowledge)'),
            (b'\x15', 'NAK (Negative Acknowledge)'),
            (b'\x02', 'STX (Start of Text)'),
            (b'\x03', 'ETX (End of Text)'),
            (b'\x04', 'EOT (End of Transmission)'),
            (b'\x1a', 'SUB (Substitute)'),
            (b'\x11', 'DC1 (Device Control 1)'),
            (b'\x13', 'DC3 (Device Control 3)'),
        ]
        
        for cmd, desc in test_commands:
            try:
                print(f"\n📤 Wysyłam: {desc}")
                print(f"   Hex: {cmd.hex()}")
                
                # Wyczyść bufor wejściowy
                connection.flushInput()
                
                # Wyślij komendę
                connection.write(cmd)
                time.sleep(0.5)
                
                # Sprawdź odpowiedź
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        print(f"   Tekst: [nieparsowalne]")
                else:
                    print(f"⚠️ Brak odpowiedzi na {desc}")
                    
            except Exception as e:
                print(f"❌ Błąd komendy {desc}: {e}")
        
        # Test kombinacji DLE + inne bajty (jeśli DLE działa)
        print(f"\n📤 Test kombinacji DLE + inne bajty:")
        
        dle_commands = [
            (b'\x10\x10', 'DLE DLE'),
            (b'\x10\x05', 'DLE ENQ'),
            (b'\x10\x53', 'DLE S'),
            (b'\x10\x54', 'DLE T'),
            (b'\x10\x50', 'DLE P'),
            (b'\x10\x45', 'DLE E'),
            (b'\x10\x52', 'DLE R'),
            (b'\x10\x58', 'DLE X'),
            (b'\x10\x5A', 'DLE Z'),
        ]
        
        for cmd, desc in dle_commands:
            try:
                print(f"\n📤 Wysyłam: {desc}")
                print(f"   Hex: {cmd.hex()}")
                
                connection.flushInput()
                connection.write(cmd)
                time.sleep(0.5)
                
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        print(f"   Tekst: [nieparsowalne]")
                else:
                    print(f"⚠️ Brak odpowiedzi na {desc}")
                    
            except Exception as e:
                print(f"❌ Błąd komendy {desc}: {e}")
        
        connection.close()
        print(f"\n✅ Test zakończony pomyślnie")
        
    except Exception as e:
        print(f"❌ Błąd testu: {e}")

if __name__ == "__main__":
    test_simple_novitus()
