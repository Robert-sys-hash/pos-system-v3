#!/usr/bin/env python3
"""
Test specyficzny dla drukarki Novitus - sprawdzenie protokołu komunikacji
"""

import serial
import time
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_novitus_protocol():
    """Test protokołu Novitus"""
    try:
        port = '/dev/cu.usbmodem1101'
        baudrate = 9600
        
        print(f"🔍 Nawiązuję połączenie z drukarką Novitus na {port}")
        
        connection = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=3.0
        )
        
        print(f"✅ Połączenie nawiązane: {connection.is_open}")
        
        # Test komend charakterystycznych dla Novitus
        test_commands = [
            # ESC ENQ - zapytanie o status
            ('\x1B\x05', 'Status Query (ESC ENQ)'),
            # ESC @ - reset drukarki  
            ('\x1B\x40', 'Reset Printer (ESC @)'),
            # Sprawdzenie wersji firmware
            ('\x1B\x76', 'Version Query (ESC v)'),
            # Status fiskalny
            ('\x1B\x73', 'Fiscal Status (ESC s)'),
        ]
        
        for cmd, desc in test_commands:
            try:
                print(f"\n📤 Wysyłam: {desc}")
                print(f"   Hex: {cmd.encode('latin1').hex()}")
                
                # Wyczyść bufor wejściowy
                connection.flushInput()
                
                # Wyślij komendę
                connection.write(cmd.encode('latin1'))
                time.sleep(1.0)
                
                # Sprawdź odpowiedź
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        print(f"   Tekst: [nieparsowalne]")
                else:
                    print(f"⚠️ Brak odpowiedzi na {desc}")
                    
            except Exception as e:
                print(f"❌ Błąd komendy {desc}: {e}")
        
        # Test protokołu XML (jeśli Novitus go obsługuje)
        print(f"\n📤 Test protokołu XML:")
        try:
            xml_cmd = '<?xml version="1.0" encoding="windows-1250"?>\n<root><GetStatus/></root>\n'
            print(f"   XML: {xml_cmd}")
            
            connection.flushInput()
            connection.write(xml_cmd.encode('cp1250'))
            time.sleep(2.0)
            
            if connection.in_waiting > 0:
                response = connection.read(connection.in_waiting)
                print(f"📥 Odpowiedź XML ({len(response)} bajtów): {response}")
                try:
                    decoded = response.decode('cp1250', errors='ignore')
                    print(f"   XML Response: {decoded}")
                except:
                    print(f"   Hex: {response.hex()}")
            else:
                print(f"⚠️ Brak odpowiedzi na XML")
                
        except Exception as e:
            print(f"❌ Błąd XML: {e}")
        
        connection.close()
        print(f"\n✅ Test zakończony pomyślnie")
        
    except Exception as e:
        print(f"❌ Błąd testu Novitus: {e}")

if __name__ == "__main__":
    test_novitus_protocol()
