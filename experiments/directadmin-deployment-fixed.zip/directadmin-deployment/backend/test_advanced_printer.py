#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import serial
import time
import sys

def test_multiple_configs():
    """Test różnych konfiguracji komunikacji z drukarką"""
    
    port = '/dev/cu.usbmodem101'
    
    # Różne konfiguracje do przetestowania
    configs = [
        {'baudrate': 9600, 'desc': 'Standardowa 9600'},
        {'baudrate': 19200, 'desc': 'Szybsza 19200'},
        {'baudrate': 38400, 'desc': 'Szybsza 38400'},
        {'baudrate': 4800, 'desc': 'Wolniejsza 4800'},
        {'baudrate': 2400, 'desc': 'Bardzo wolna 2400'},
    ]
    
    print(f"🔌 Testowanie różnych konfiguracji na {port}")
    print("=" * 60)
    
    for config in configs:
        baudrate = config['baudrate']
        desc = config['desc']
        
        print(f"\n📊 Test konfiguracji: {desc} ({baudrate} baud)")
        print("-" * 40)
        
        try:
            ser = serial.Serial(
                port=port,
                baudrate=baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=3,  # Dłuższy timeout
                xonxoff=False,
                rtscts=False,
                dsrdtr=False
            )
            
            print(f"✅ Port otwarty z {baudrate} baud")
            
            # Poczekaj na stabilizację
            time.sleep(1)
            
            # Wyczyść bufory
            ser.reset_input_buffer()
            ser.reset_output_buffer()
            
            # Test ENQ
            print("🔍 Wysyłam ENQ...")
            ser.write(b'\x05')
            ser.flush()
            time.sleep(2)  # Dłuższa pauza
            
            response = ser.read_all()
            if response:
                print(f"✅ ENQ -> Odpowiedź: {response.hex()}")
                # Jeśli dostaliśmy odpowiedź, sprawdźmy więcej komend
                
                # Test inicjalizacji ESC-P
                print("🔍 Wysyłam inicjalizację ESC-P...")
                ser.write(b'\x1B@')  # ESC @
                ser.flush()
                time.sleep(1)
                
                response2 = ser.read_all()
                if response2:
                    print(f"✅ ESC@ -> Odpowiedź: {response2.hex()}")
                
                # Test komendy statusu Novitus
                print("🔍 Wysyłam komendę statusu Novitus...")
                ser.write(b'$s\r\n')  # $s status command
                ser.flush()
                time.sleep(1)
                
                response3 = ser.read_all()
                if response3:
                    print(f"✅ $s -> Odpowiedź: {response3.hex()}")
                    print(f"   ASCII: {response3.decode('ascii', errors='ignore')}")
                
            else:
                print("❌ Brak odpowiedzi na ENQ")
            
            ser.close()
            
        except Exception as e:
            print(f"❌ Błąd dla {baudrate}: {e}")
    
    print("\n" + "=" * 60)
    print("🔍 Test zakończony - sprawdzanie dodatkowych możliwości...")
    
    # Test czy drukarka wysyła dane automatycznie po podłączeniu
    try:
        ser = serial.Serial(port, 9600, timeout=5)
        print("\n📡 Sprawdzam czy drukarka wysyła dane po otwarciu połączenia...")
        time.sleep(3)
        
        auto_data = ser.read_all()
        if auto_data:
            print(f"📥 Automatyczne dane: {auto_data.hex()}")
            print(f"   ASCII: {auto_data.decode('ascii', errors='ignore')}")
        else:
            print("📭 Brak automatycznych danych")
        
        ser.close()
    except Exception as e:
        print(f"❌ Błąd testu automatycznych danych: {e}")

if __name__ == "__main__":
    print("🖨️ TEST RÓŻNYCH KONFIGURACJI DRUKARKI NOVITUS DEON")
    print("📋 Sprawdzanie różnych prędkości i komend")
    print()
    
    test_multiple_configs()
