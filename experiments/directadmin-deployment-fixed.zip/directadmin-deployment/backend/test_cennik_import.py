#!/usr/bin/env python3
"""
Test importu cennika XML do bazy danych
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.database import execute_query, execute_insert
import xml.etree.ElementTree as ET
from datetime import datetime

def parse_cennik_xml(file_path):
    """
    Parsuje plik XML cennika
    """
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        products = []
        
        # Parsuj produkty z XML
        for towar in root.findall('.//TOWAR'):
            try:
                product = {}
                
                # Podstawowe dane
                kod = towar.find('KOD')
                product['kod'] = kod.text if kod is not None else ''
                
                ean = towar.find('EAN')
                product['ean'] = ean.text if ean is not None else ''
                
                nazwa = towar.find('NAZWA')
                product['nazwa'] = nazwa.text if nazwa is not None else ''
                
                jm = towar.find('JM')
                product['jednostka'] = jm.text if jm is not None else 'szt.'
                
                # VAT
                stawka_vat = towar.find('.//STAWKA_VAT/STAWKA')
                product['stawka_vat'] = float(stawka_vat.text) if stawka_vat is not None else 23.0
                
                # Cena
                cena = towar.find('.//CENA/WARTOSC')
                if cena is not None:
                    cena_brutto = float(cena.text)
                    product['cena_brutto'] = cena_brutto
                    product['cena_netto'] = round(cena_brutto / (1 + product['stawka_vat'] / 100), 2)
                else:
                    product['cena_brutto'] = 0.0
                    product['cena_netto'] = 0.0
                
                products.append(product)
                
            except Exception as e:
                print(f"Błąd parsowania produktu: {e}")
                continue
        
        return {
            'success': True,
            'products': products
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': f'Błąd parsowania cennika XML: {str(e)}'
        }

def save_products_to_database(products, filename):
    """
    Zapisuje produkty z cennika do bazy danych
    """
    stats = {
        'created': 0,
        'updated': 0,
        'skipped': 0,
        'errors': []
    }
    
    try:
        for product in products:
            try:
                # Sprawdź czy produkt istnieje (po kodzie lub EAN)
                existing_sql = """
                SELECT id FROM produkty 
                WHERE kod_produktu = ? OR ean = ?
                LIMIT 1
                """
                existing = execute_query(existing_sql, (product.get('kod', ''), product.get('ean', '')))
                
                if existing:
                    # Aktualizuj istniejący produkt
                    update_sql = """
                    UPDATE produkty 
                    SET cena = ?, cena_zakupu = ?, stawka_vat = ?, nazwa = ?, jednostka = ?
                    WHERE id = ?
                    """
                    execute_query(update_sql, (
                        product.get('cena_brutto', 0),
                        product.get('cena_netto', 0),
                        product.get('stawka_vat', 23),
                        product.get('nazwa', ''),
                        product.get('jednostka', 'szt.'),
                        existing[0]['id']
                    ))
                    stats['updated'] += 1
                else:
                    # Utwórz nowy produkt
                    insert_sql = """
                    INSERT INTO produkty (
                        kod_produktu, ean, nazwa, stawka_vat, jednostka,
                        cena, cena_zakupu, aktywny, data_utworzenia, 
                        user_login, zrodlo_importu
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, 'system', 'cennik')
                    """
                    execute_insert(insert_sql, (
                        product.get('kod', ''),
                        product.get('ean', ''),
                        product.get('nazwa', ''),
                        product.get('stawka_vat', 23),
                        product.get('jednostka', 'szt.'),
                        product.get('cena_brutto', 0),
                        product.get('cena_netto', 0),
                        datetime.now().isoformat()
                    ))
                    stats['created'] += 1
                    
            except Exception as e:
                stats['errors'].append(f"Błąd produktu {product.get('kod', '')}: {str(e)}")
                continue
        
        return {
            'success': True,
            'stats': stats
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

def auto_map_invoice_items(invoice_id):
    """
    Automatyczne mapowanie pozycji faktury do produktów z bazy danych
    """
    try:
        # Pobierz niezmapowane pozycje faktury
        items_sql = """
        SELECT id, kod_produktu, ean, nazwa_produktu
        FROM faktury_zakupowe_pozycje 
        WHERE faktura_id = ? AND status_mapowania = 'niezmapowany'
        """
        
        unmapped_items = execute_query(items_sql, (invoice_id,))
        if not unmapped_items:
            return {'success': True, 'mapped_count': 0, 'message': 'Brak niezmapowanych pozycji'}
        
        mapped_count = 0
        verification_count = 0
        
        for item in unmapped_items:
            item_id = item['id']
            kod_produktu = item['kod_produktu']
            ean = item['ean']
            
            produkt_id = None
            status = 'niezmapowany'
            
            # Priorytet 1: Mapowanie po kodzie produktu
            if kod_produktu:
                product_result = execute_query("SELECT id, nazwa FROM produkty WHERE kod_produktu = ?", (kod_produktu,))
                if product_result:
                    produkt_id = product_result[0]['id']
                    status = 'zmapowany'
                    mapped_count += 1
            
            # Priorytet 2: Fallback - mapowanie po EAN (jeśli kod_produktu nie pasuje)
            if not produkt_id and ean:
                product_result = execute_query("SELECT id, nazwa FROM produkty WHERE ean = ?", (ean,))
                if product_result:
                    produkt_id = product_result[0]['id']
                    status = 'wymaga_weryfikacji'  # EAN może się zmieniać, więc wymaga weryfikacji
                    verification_count += 1
            
            # Aktualizuj pozycję faktury
            if produkt_id:
                update_sql = """
                UPDATE faktury_zakupowe_pozycje 
                SET produkt_id = ?, status_mapowania = ?
                WHERE id = ?
                """
                execute_query(update_sql, (produkt_id, status, item_id))
        
        return {
            'success': True,
            'mapped_by_code': mapped_count,
            'mapped_by_ean': verification_count,
            'total_processed': len(unmapped_items)
        }
        
    except Exception as e:
        print(f"Błąd automatycznego mapowania: {e}")
        return {'success': False, 'error': str(e)}

def main():
    """Główna funkcja testowa"""
    
    # Sprawdź aktualny stan
    print("📊 AKTUALNY STAN BAZY:")
    
    products_count = execute_query("SELECT COUNT(*) as count FROM produkty")
    print(f"   Produkty w bazie: {products_count[0]['count'] if products_count else 0}")
    
    unmapped_count = execute_query("SELECT COUNT(*) as count FROM faktury_zakupowe_pozycje WHERE status_mapowania = 'niezmapowany'")
    print(f"   Niezmapowane pozycje: {unmapped_count[0]['count'] if unmapped_count else 0}")
    
    # Test automatycznego mapowania
    print("\n🔗 TESTOWANIE AUTOMATYCZNEGO MAPOWANIA:")
    result = auto_map_invoice_items(1)
    
    if result['success']:
        print(f"   ✅ Zmapowano {result.get('mapped_by_code', 0)} pozycji po kodzie produktu")
        print(f"   ⚠️  Zmapowano {result.get('mapped_by_ean', 0)} pozycji po EAN (wymaga weryfikacji)")
        print(f"   📋 Przetworzono {result.get('total_processed', 0)} pozycji łącznie")
    else:
        print(f"   ❌ Błąd mapowania: {result.get('error', 'Nieznany błąd')}")
    
    # Sprawdź stan po mapowaniu
    print("\n📊 STAN PO MAPOWANIU:")
    unmapped_after = execute_query("SELECT COUNT(*) as count FROM faktury_zakupowe_pozycje WHERE status_mapowania = 'niezmapowany'")
    mapped_after = execute_query("SELECT COUNT(*) as count FROM faktury_zakupowe_pozycje WHERE status_mapowania = 'zmapowany'")
    
    print(f"   Niezmapowane pozycje: {unmapped_after[0]['count'] if unmapped_after else 0}")
    print(f"   Zmapowane pozycje: {mapped_after[0]['count'] if mapped_after else 0}")

if __name__ == "__main__":
    main()
