#!/usr/bin/env python3
"""
Test podstawowego endpointu faktury zakupowej
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.database import execute_query

def test_invoice_query():
    try:
        # Test podstawowego zapytania faktury
        invoice_sql = "SELECT * FROM faktury_zakupowe WHERE id = ?"
        result = execute_query(invoice_sql, (1,))
        
        if result:
            print("✅ Zapytanie faktury OK")
            print(f"Znaleziono: {len(result)} rekordów")
            
            # Test pozycji faktury
            items_sql = "SELECT * FROM faktury_zakupowe_pozycje WHERE faktura_id = ?"
            items_result = execute_query(items_sql, (1,))
            
            if items_result:
                print(f"✅ Pozycje faktury OK: {len(items_result)} pozycji")
                return {
                    'success': True,
                    'invoice': result[0],
                    'items': items_result,
                    'message': f'Faktura znaleziona z {len(items_result)} pozycjami'
                }
            else:
                print("⚠️ Brak pozycji faktury")
                return {
                    'success': True,
                    'invoice': result[0],
                    'items': [],
                    'message': 'Faktura znaleziona ale bez pozycji'
                }
        else:
            print("❌ Faktura nie znaleziona")
            return {
                'success': False,
                'error': 'Faktura nie znaleziona'
            }
            
    except Exception as e:
        print(f"❌ Błąd: {e}")
        return {
            'success': False,
            'error': str(e)
        }

if __name__ == '__main__':
    result = test_invoice_query()
    print("\nWynik testu:")
    print(result)
