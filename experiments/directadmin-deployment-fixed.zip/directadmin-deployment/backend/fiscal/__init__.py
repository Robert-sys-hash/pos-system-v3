# Moduł obsługi urządzeń fiskalnych
