#!/usr/bin/env python3
"""
Skrypt do testowania komunikacji z drukarką Novitus Deon
Sprawdza różne porty i ustawienia komunikacji
"""

import serial
import time
import sys

def test_printer_comprehensive():
    """Kompleksowy test komunikacji z drukarką fiskalną"""
    
    # Dostępne porty do sprawdzenia
    ports = [
        '/dev/cu.usbmodem101',
        '/dev/cu.usbmodem103', 
        '/dev/tty.usbmodem101',
        '/dev/tty.usbmodem103'
    ]
    
    # Różne prędkości do sprawdzenia
    baudrates = [9600, 19200, 38400, 57600, 115200]
    
    print("🔍 KOMPLEKSOWY TEST KOMUNIKACJI Z DRUKARKĄ NOVITUS DEON")
    print("=" * 60)
    
    for port in ports:
        print(f"\n🔌 Testowanie portu: {port}")
        
        for baudrate in baudrates:
            print(f"  📡 Baudrate: {baudrate}")
            
            try:
                with serial.Serial(port, baudrate, timeout=1, bytesize=8, parity='N', stopbits=1) as ser:
                    # Sprawdź czy port się otworzył
                    if not ser.is_open:
                        ser.open()
                    
                    time.sleep(0.1)  # Krótka pauza
                    
                    # Test 1: ENQ (05) - sprawdzenie statusu
                    print(f"    🧪 Test ENQ (05)...")
                    ser.write(bytes([0x05]))
                    time.sleep(0.2)
                    
                    response = ser.read(10)
                    if response:
                        print(f"    ✅ Odpowiedź ENQ: {response.hex()} (raw: {response})")
                        
                        # Test 2: DLE ENQ (10 05) - status fiskalny
                        print(f"    🧪 Test DLE ENQ (10 05)...")
                        ser.write(bytes([0x10, 0x05]))
                        time.sleep(0.2)
                        
                        response2 = ser.read(10)
                        if response2:
                            print(f"    ✅ Odpowiedź DLE ENQ: {response2.hex()} (raw: {response2})")
                            print(f"    🎉 ZNALEZIONO DZIAŁAJĄCĄ DRUKARKĘ!")
                            print(f"    📍 Port: {port}")
                            print(f"    ⚡ Baudrate: {baudrate}")
                            print(f"    📋 Konfiguracja do użycia:")
                            print(f"         'port_macos': '{port}',")
                            print(f"         'baudrate': {baudrate},")
                            return port, baudrate
                        else:
                            print(f"    ❌ Brak odpowiedzi na DLE ENQ")
                    else:
                        print(f"    ❌ Brak odpowiedzi na ENQ")
                        
            except Exception as e:
                if "No such file or directory" not in str(e):
                    print(f"    ❌ Błąd: {e}")
    
    print(f"\n❌ Nie znaleziono działającej drukarki na żadnym porcie")
    print(f"💡 Sprawdź czy:")
    print(f"   1. Drukarka jest włączona")
    print(f"   2. Kabel USB jest podłączony")
    print(f"   3. Drukarka jest w trybie fiskalnym")
    print(f"   4. System rozpoznaje urządzenie USB")
    
    return None, None

if __name__ == "__main__":
    print("🚀 Rozpoczynam test komunikacji z drukarką...")
    port, baudrate = test_printer_comprehensive()
    
    if port and baudrate:
        print(f"\n🎯 GOTOWE DO FISKALIZACJI!")
        print(f"Użyj tej konfiguracji w config.py:")
        print(f"'port_macos': '{port}',")
        print(f"'baudrate': {baudrate},")
    else:
        print(f"\n⚠️  Drukarka nie została wykryta")
        print(f"System przejdzie w tryb symulacji")
