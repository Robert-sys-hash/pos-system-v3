#!/usr/bin/env python3
"""
Test nowych komend SUB dla drukarki Novitus
"""

import serial
import time

def test_new_novitus_commands():
    """Test nowych komend SUB"""
    try:
        port = '/dev/cu.usbmodem1101'
        baudrate = 9600
        
        print(f"🔍 Test nowych komend SUB dla Novitus na {port}")
        
        connection = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=2.0
        )
        
        print(f"✅ Połączenie nawiązane: {connection.is_open}")
        
        # Test nowych komend SUB + literka
        new_commands = [
            (b'\x1a\x4F', 'SUB + O (Open) - otwieranie paragonu'),
            (b'\x1a\x49', 'SUB + I (Item) - dodanie pozycji'),
            (b'\x1a\x50', 'SUB + P (Payment) - płatność'),
            (b'\x1a\x43', 'SUB + C (Close) - zamknięcie paragonu'),
            (b'\x1a\x58', 'SUB + X (X Report)'),
            (b'\x1a\x5A', 'SUB + Z (Z Report)'),
            (b'\x1a\x53', 'SUB + S (Status/Start)'),
            (b'\x1a\x45', 'SUB + E (End)'),
            (b'\x1a\x52', 'SUB + R (Receipt)'),
            (b'\x1a\x54', 'SUB + T (Total)'),
        ]
        
        for cmd, desc in new_commands:
            try:
                print(f"\n📤 {desc}")
                print(f"   Komenda: {cmd.hex()}")
                
                connection.flushInput()
                connection.write(cmd)
                time.sleep(0.5)
                
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        pass
                else:
                    print(f"⚠️ Brak odpowiedzi")
                    
            except Exception as e:
                print(f"❌ Błąd: {e}")
        
        # Test komend z parametrami
        print(f"\n📤 Test komend z parametrami:")
        
        parameter_commands = [
            (b'\x1a\x4F\x31', 'SUB + O + 1 (Open online)'),
            (b'\x1a\x4F\x30', 'SUB + O + 0 (Open offline)'),
            (b'\x1a\x49Test|100.00|1\x0D', 'SUB + I + dane produktu'),
            (b'\x1a\x50\x30100.00\x0D', 'SUB + P + płatność gotówka'),
            (b'\x1a\x43100.00|Kasjer\x0D', 'SUB + C + zamknięcie'),
        ]
        
        for cmd, desc in parameter_commands:
            try:
                print(f"\n📤 {desc}")
                print(f"   Komenda: {cmd.hex()}")
                
                connection.flushInput()
                connection.write(cmd)
                time.sleep(0.5)
                
                if connection.in_waiting > 0:
                    response = connection.read(connection.in_waiting)
                    print(f"📥 Odpowiedź ({len(response)} bajtów): {response}")
                    print(f"   Hex: {response.hex()}")
                    try:
                        decoded = response.decode('cp1250', errors='ignore')
                        print(f"   Tekst: {repr(decoded)}")
                    except:
                        pass
                else:
                    print(f"⚠️ Brak odpowiedzi")
                    
            except Exception as e:
                print(f"❌ Błąd: {e}")
        
        connection.close()
        print(f"\n✅ Test zakończony")
        
    except Exception as e:
        print(f"❌ Błąd testu: {e}")

if __name__ == "__main__":
    test_new_novitus_commands()
